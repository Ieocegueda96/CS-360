package com.zybooks.eventtrackingisaaco;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    EditText username, password, pass2;
    Button register, signin;
    LoginDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = (EditText) findViewById(R.id.newUsername);
        password = (EditText) findViewById(R.id.newPassword);
        pass2 = (EditText) findViewById(R.id.rePassword);

        register = (Button)  findViewById(R.id.signUpB);
        signin = (Button) findViewById(R.id.signInB);

        db = new LoginDatabase(this);

        //this lets users register with what they put for username and password
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = pass2.getText().toString();

                //checking for data
                if(user.isEmpty() || (pass.isEmpty() || repass.isEmpty()))
                    Toast.makeText(Register.this, "Please check all fields", Toast.LENGTH_SHORT).show();
                else{
                    //makes sure passwords are the same
                    if(pass.equals(repass)){
                        //checks for username in the database
                        Boolean checkuser = db.checkUsername(user);
                        if(!checkuser){
                            //puts the username and the password into the database
                            Boolean insert = db.insertData(user, pass);
                            //start the home
                            if(insert){
                                Toast.makeText(Register.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), home.class);
                                startActivity(intent);
                            }
                            else{
                                Toast.makeText(Register.this, "User already exists you can sign in", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(Register.this, "User already exists you can sign in", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(Register.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //takes you to log in
        signin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        });
    }
}